# flutter_i18n_json

This flutter project base on official internationalization document of flutter: https://flutter.io/tutorials/internationalization/
and Dartlang "dart:convert" library
